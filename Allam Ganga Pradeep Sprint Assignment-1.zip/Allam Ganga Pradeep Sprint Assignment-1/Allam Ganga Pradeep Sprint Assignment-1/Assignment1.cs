﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Allam_Ganga_Pradeep_Sprint_Assignment_1
{
    public class Student
    {
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string smailid { get; set; }
        public string branch { get; set; }
        public double per { get; set; }
    }
    internal class Assignment1
    {
        public void task1()
        {
            Console.WriteLine("-----------Task-1----------");
            List<Student> students = new List<Student>()
            {
                new Student(){ firstname = "Ganga", lastname = "Pradeep", smailid = "ganga.pradeep@gmail.com", branch = "CSE", per = 90.04},
                new Student(){ firstname = "Allam", lastname = "Pradeep", smailid = "ganga.pradeep3@gmail.com", branch = "CSE", per = 92.05},
                new Student(){ firstname = "Ganga", lastname = "Allam", smailid = "ganga.pradeep330@gmail.com", branch = "CSE", per = 95.04},
                new Student(){ firstname = "Pradeep", lastname = "Allam", smailid = "ganga.pradeep340@gmail.com", branch = "CSE", per = 93.20}
            };
            
            var query1 = from i in students select i;
            Console.WriteLine("\n-------------Select query---------------");
            Console.WriteLine("All the items from students list\n");
            foreach(var i in query1)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n---------------Where query--------------");
            Console.WriteLine("All the items where lastname == Pradeep\n");
            var query2 = students.Where(i=>i.lastname=="Pradeep");
            foreach (var i in query2)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n-------------Take query---------------");
            Console.WriteLine("Taking top 3 items in the list\n");
            var query3 = students.Take(3);
            foreach (var i in query3)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n------------TakeWhile query-------------");
            Console.WriteLine("Taking the items until the firstname==Ganga\n");
            var query4 = students.TakeWhile(i => i.firstname == "Ganga");
            foreach (var i in query4)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n------------Skip query-------------");
            Console.WriteLine("Skipping first 2 items in the list\n");
            var query5 = students.Skip(2);
            foreach (var i in query5)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n-----------SkipWhile query------------");
            Console.WriteLine("Skipping queries untill the firstname == Ganga\n");
            var query6 = students.SkipWhile(i => i.firstname == "Ganga");
            foreach(var i in query6)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n-----------OrderBy query---------------");
            Console.WriteLine("Ordering the items based on the per value\n");
            Console.WriteLine("1.Asending order");
            var query7 = students.OrderBy(i => i.per);
            foreach (var i in query7)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n2.Decending Order");
            var query8 = students.OrderByDescending(i => i.per);
            foreach (var i in query8)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n------------GroupBy query------------------");
            Console.WriteLine("Grouping by the per<95\n");
            var query9 = (students.GroupBy(i=>i.per<95));
            foreach (var j in query9)
            {
                Console.WriteLine($"Key:{j.Key}(per<95)");
                Console.WriteLine("Values:");
                foreach (var i in j)
                {
                    Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
                }
            }
            List<List<int>> arr = new List<List<int>>();
            List<int> arrIn = new List<int> { 1, 2, 3 };
            arr.Add(arrIn);
            Console.WriteLine("\n-------------SelectMany query-----------------");
            Console.WriteLine("Quering a list of lists using SelectMany\n");
            var query10 = arr.SelectMany(i=>i);
            foreach (var i in query10)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("\n-------------Aggregate Functions---------------");
            Console.WriteLine("\n1.Sum of all per");
            var query11 = students.Sum(i => i.per);
            Console.WriteLine($"Sum of all per = {query11}");
            Console.WriteLine("\n2.Max of per");
            var query12 = students.Max(i => i.per);
            Console.WriteLine($"Max of per = {query12}");
            Console.WriteLine("\n3.Min of per");
            var query13 = students.Min(i => i.per);
            Console.WriteLine($"Min of per = {query13}");
            Console.WriteLine("\n4.Avg of per");
            var query14 = students.Average(i=>i.per);
            Console.WriteLine($"Average of per = {query14}");
            Console.WriteLine("\n5.Count of per<95");
            var query15 = students.Count(i=>i.per<95);
            Console.WriteLine($"Count = {query15}");
            Console.WriteLine("\n6.Distinct");
            Console.WriteLine("All the distinct items of the li1 array");
            List<int> li1 = new List<int>() { 1, 1, 2, 2, 3, 4, 5 };
            List<int> li2 = new List<int>() { 1, 1, 2, 2, 5, 6, 7 };
            var query16 = li1.Distinct();
            foreach (var i in query16)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("\n-----------Let Query---------------");
            Console.WriteLine("Changing the values of the li1 items by adding some numbers to it");
            var query17 = from i in li1 let res = i+20 select res;
            foreach (var i in query17)
            {
                Console.WriteLine($"{i}");
            }
            List<Student> students2 = new List<Student>()
            {
                new Student(){ firstname = "Ganga", lastname = "Pradeep", smailid = "ganga.pradeep@gmail.com", branch = "IT", per = 93.04},
                new Student(){ firstname = "Allam", lastname = "Pradeep", smailid = "ganga.pradeep3@gmail.com", branch = "IT", per = 92.05},
                new Student(){ firstname = "Ganga", lastname = "Allam", smailid = "ganga.pradeep@gmail.com", branch = "IT", per = 96.04},
                new Student(){ firstname = "Pradeep", lastname = "Allam", smailid = "ganga.pradeep@gmail.com", branch = "IT", per = 97.20}
            };
            Console.WriteLine("\n-----------Into Query-------------");
            Console.WriteLine("\n Joins equal per items in students and students2");
            var query18 = from i in students
                          join j in students2 on i.per equals j.per into res
                          select res;
            foreach (var j in query18)
            {
                foreach(var i in j)
                {
                    Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
                }
            }
            object[] obj = new object[] { 1,"String",2,"Double",0};
            Console.WriteLine("\n---------------Oftype Query-------------");
            Console.WriteLine("All the integer type values in the obj");
            var query19 = obj.OfType<int>();
            foreach (var i in query19)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("\n------------First Query--------------");
            var query20 = students.Where(i => i.per < 95).First();
            Console.WriteLine($"{query20.firstname},{query20.lastname},{query20.smailid},{query20.branch},{query20.per}");
            Console.WriteLine("\n------------FirstOrDefault Query--------------");
            var query21 = students.Where(i => i.per > 100).FirstOrDefault();
            Console.WriteLine($"Value = {query21}");
            Console.WriteLine("\n------------Last Query--------------");
            var query22 = students.Where(i => i.per < 95).Last();
            Console.WriteLine($"{query22.firstname},{query22.lastname},{query22.smailid},{query22.branch},{query22.per}");
            Console.WriteLine("\n------------LastOrDefault Query--------------");
            var query23 = students.Where(i => i.per > 100).LastOrDefault();
            Console.WriteLine($"Value = {query23}");
            Console.WriteLine("\n------------Single Query--------------");
            var query24 = students.Where(i => i.per > 95).Single();
            Console.WriteLine($"{query24.firstname},{query24.lastname},{query24.smailid},{query24.branch},{query24.per}");
            Console.WriteLine("\n------------SingleOrDefault Query--------------");
            var query25 = students.Where(i => i.per > 100).SingleOrDefault();
            Console.WriteLine($"Value = {query21}");
            Console.WriteLine($"\n-----------Deffrered Execution-----------------");
            var query26 = from i in students select i;
            students.Add(new Student() { firstname="Pradeep", lastname = "Ganga", smailid="pradeep@gmail.com",branch = "ECE", per = 99});
            foreach(var i in query26)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine($"\n-----------Immediate Execution-----------------");
            var query27 = (from i in students where i.per < 95 select i).Count();
            students.Add(new Student() { firstname = "Pradeep", lastname = "A", smailid = "pradeep@gmail.com", branch = "ECE", per = 92 });
            Console.WriteLine($"Count of all values pre<95 : {query27}");
            Console.WriteLine("\n------------StartsWith Query-------------------");
            var query28 = students.Where(i => i.firstname.StartsWith('A'));
            foreach(var i in query28)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n------------EndsWith Query-------------------");
            var query29 = students.Where(i => i.firstname.EndsWith('p'));
            foreach (var i in query29)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n------------Contains Query-------------------");
            var query30 = students.Where(i => i.firstname.Contains('a'));
            foreach (var i in query30)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n-------------IEnumarable---------------");
            IEnumerable<Student> query31 = from i in students select i;
            query31 = query31.Take(2);
            foreach (var i in query31)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n-------------IQuerable-----------------");
            IQueryable<Student> query32 = students.AsQueryable();
            query32 = query32.Take(2);
            foreach(var i in query32)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
        }
        public void task2()
        {
            Console.WriteLine("------------Task-2---------------");
            int[] arr1 = new int[] { 1, 2, 3, 5 };
            int[] arr2 = new int[] { 1, 2, 7, 8 };
            var query1 = arr1.Except(arr2);
            Console.WriteLine("\n------------Expect Query-----------");
            foreach(var i in query1)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("\n-------------Union Query------------");
            var query2 = arr1.Union(arr2);
            foreach (var i in query2)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("---------------Intersect Query----------");
            var query3 = arr1.Intersect(arr2);
            foreach (var i in query3)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("---------------Concat Query----------");
            var query4 = arr1.Concat(arr2);
            foreach (var i in query4)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("\n-------------Aggregate Functions---------------");
            var query11 = arr1.Sum(i => i);
            Console.WriteLine($"\n1.Sum of all elements in arr1 = {query11}");
            var query12 = arr1.Max(i => i);
            Console.WriteLine($"\n2.Max of all elements in arr1 = {query12}");
            var query13 = arr1.Min(i => i);
            Console.WriteLine($"\n3.Min of all elements in arr1 = {query13}");
            var query14 = arr1.Average(i => i);
            Console.WriteLine($"\n4.Average of all elements in arr1 = {query14}");
            Console.WriteLine("\n5.Count of all elements in arr1<5");
            var query15 = arr1.Count(i => i < 5);
            Console.WriteLine($"Count = {query15}");
            Console.WriteLine("\n6.Distinct");
            Console.WriteLine("All the distinct items of the arr1 array");
            var query16 = arr1.Distinct();
            foreach (var i in query16)
            {
                Console.WriteLine($"{i}");
            }
        }
    }
}
