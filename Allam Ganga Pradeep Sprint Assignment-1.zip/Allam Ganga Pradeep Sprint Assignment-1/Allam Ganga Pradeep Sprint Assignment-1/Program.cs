﻿using System;

namespace Allam_Ganga_Pradeep_Sprint_Assignment_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Assignment1 assignment1 = new Assignment1();
            assignment1.task1();
            assignment1.task2();
            Console.ReadKey();
        }
    }
}
